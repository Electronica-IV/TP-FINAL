Files in this zip archive:
THS4271.asy		789 bytes
THS4271_Test.asc	1732 bytes
THS4271.sub		5377 bytes
Readme.txt	(this file)	494 bytes

This set is adapted from the Spice model for the THS4271
from the Texas Instruments web site, file sloj151.zip.  The
key change is that the pin assignments have been made to
correspond to the pins on an 8-pin package for this part.
This enables more graceful use of an exported netlist in the
FreePCB PC layout program.

Tom Bruhns
2008-08-12
