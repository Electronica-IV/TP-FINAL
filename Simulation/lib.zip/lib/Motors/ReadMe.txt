1. New BLDC Motor model includes BEMF A-B-C outputs

2. BLDC.lib: Added new motor models

Note: Jm parameter is not the real value in most of the cases
      Dm parameters are specified by experimental measurements

09/09/2015    

� Peter Kapas
pkapas@sbcglobal.net