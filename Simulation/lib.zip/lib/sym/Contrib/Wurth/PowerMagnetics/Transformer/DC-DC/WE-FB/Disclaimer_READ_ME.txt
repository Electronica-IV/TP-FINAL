﻿**************************************************
Manufacturer:           Wurth Elektronik 
Contact:                libraries@we-online.com
**************************************************
Disclaimer: While Würth Elektronik eiSos has made every reasonable effort to ensure the accuracy
of the simulation models provided, Würth Elektronik eiSos does not guarantee the exemption of error on
the simulation models, nor does Würth Elektronik eiSos guarantee that the simulation model is current.
Würth Elektronik eiSos reserves the right to make any adjustments at any time without notice.
Würth Elektronik eiSos expressly disclaims all implied warranties regarding this simulation model.
**************************************************